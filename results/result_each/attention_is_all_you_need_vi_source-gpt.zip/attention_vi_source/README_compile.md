# Attention Is All You Need - bản dịch tiếng Việt

## Cách biên dịch

Yêu cầu: XeLaTeX/latexmk và font Noto Serif/Noto Sans.

```bash
latexmk -pdf -pdflatex='xelatex %O %S' attention_is_all_you_need_vi.tex
```

Các hình dùng trong tài liệu nằm trong thư mục `assets/`.
